# MailCraft - Production Build 
  
## Deployment Instructions  
  
1. Install dependencies: `npm install --production`  
2. Start the server: `npm start`  
3. Access the application at http://localhost:3000 
